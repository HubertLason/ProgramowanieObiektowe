﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Kolo : ICloneable
    {
        public Punkt srodek;
        public double promien;
        public string nazwa;

        public Kolo(Punkt srodek, float promien, string nazwa)
        {
            this.srodek = srodek;
            this.promien = promien;
            this.nazwa = nazwa;
        }
        public Kolo(Kolo other)
        {
            this.srodek = other.srodek;
            this.promien = other.promien;
            this.nazwa = other.nazwa;
        }

        public Kolo Clone()
        {
            return new Kolo(this);
        }
        object ICloneable.Clone()
        {
            return Clone();
        }

        public double obwod()
        {
            double a = 2 * 3.14 * promien;
            return a;
        }

        public override string ToString()
        {
            return base.ToString() + " srodek= " + srodek + " promien= " + promien+ " nazwa=" + nazwa;
        }


        public void przesun(double px, double py)
        {
            srodek.X = srodek.X + px;
            srodek.Y = srodek.Y + py;
        }

    }
}


