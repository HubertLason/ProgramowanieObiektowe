﻿using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            klasaA A1 = new klasaA();
            klasaA A2 = new klasaA();
            klasaB B1 = new klasaB();
            klasaB B2 = new klasaB();
            klasaC C1 = new klasaC();
            klasaC C2 = new klasaC();

            List<klasaA> ListaA = new List<klasaA> { A1, A2, B1, B2, C1, C2 }; // do listy można dodać wszystkie obiekty
            List<klasaB> ListaB = new List<klasaB> { B1, B2, C1, C2 }; // do listy można dodać obiekty klasy B i C
            List<klasaC> ListaC = new List<klasaC> { C1, C2 }; // do listy można dodać tylko obiekty klasy C

            for (int i = 0; i < ListaA.Count; i++)
            {
                ListaA[i].metoda();
                ListaA[i].metodawirtualna();
            }
            Console.WriteLine("");
            for (int i = 0; i < ListaB.Count; i++)
            {
                ListaB[i].metoda();
                ListaB[i].metodawirtualna();
            }
            Console.WriteLine("");
            for (int i = 0; i < ListaC.Count; i++)
            {
                ListaC[i].metoda();
                ListaC[i].metodawirtualna();
            }

        }
    }
    
}
