﻿using System;
using System.Collections.Generic;
namespace ConsoleApp2
{
    class Program2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Punkt punkt = new Punkt(4, 5);
            Punkt punkt1 = new Punkt(4, 6);
            punkt.przesun(0, -1);
            Console.WriteLine(punkt.ToString());
            Console.WriteLine(punkt.obwod());
            Console.WriteLine(punkt.odleglosc(punkt, punkt1));
            Kolo kolo = new Kolo(punkt1, 1, "kolo1");
            kolo.przesun(1, 2);
            Console.WriteLine(kolo.obwod());
            Console.WriteLine(kolo.ToString());
        }
    }
}
