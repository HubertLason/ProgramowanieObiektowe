﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Punkt : ICloneable
    {
        private double x;
        private double y;

        public double X
        {
            get { return x; }
            set { x = value; }
        }
        public double Y
        {
            get { return y; }
            set { y = value; }
        }
        public Punkt(double x, double y)
        {
            this.x = x;
            this.y = y;
        }

        public Punkt(Punkt other)
        {
            this.x = other.x;
            this.y = other.y;
        }

        public Punkt Clone()
        {
            return new Punkt(this);
        }
        object ICloneable.Clone()
        {
            return Clone();
        }

        public double obwod()
        {
            return 0;
        }

        public double odleglosc(Punkt a,Punkt b)
        {
            double xa = a.x;
            double xb = b.x;
            double ya = a.y;
            double yb = b.y;

            double wynik = Math.Sqrt(Math.Pow((xb - xa), 2)+Math.Pow((yb-ya),2));
            return wynik;
        }


        public override string ToString()
        {
            return base.ToString() + " x= " + x +" y="+y;
        } 

        public void przesun(double px, double py)
        {
            x = x + px;
            y = y + py;
        }

    }
}
