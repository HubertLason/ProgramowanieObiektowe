﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Trojkat : ICloneable
    {
        public Punkt w1;
        public Punkt w2;
        public Punkt w3;
        public string nazwa;

        public Trojkat(Punkt w1, Punkt w2, Punkt w3, string nazwa)
        {
            this.w1 = w1;
            this.w2 = w2;
            this.w3 = w3;
            this.nazwa = nazwa;
        }


        public Trojkat(Trojkat other)
        {
            this.w1 = other.w1;
            this.w2 = other.w2;
            this.w3 = other.w3;
            this.nazwa = other.nazwa;
        }

        public Trojkat Clone()
        {
            return new Trojkat(this);
        }
        object ICloneable.Clone()
        {
            return Clone();
        }

        public double obwod()
        {
            double a = w1.odleglosc(w1, w2) + w2.odleglosc(w2, w3) + w3.odleglosc(w3, w1);
            return a;
        }

        public override string ToString()
        {
            return base.ToString() + " w1= " + w1 + " w2=" + w2+ " w3="+w3 + " nazwa=" + nazwa;
        }

        public void przesun(double px, double py)
        {
            w1.X = w1.X + px;
            w1.Y = w1.Y + py;
            w2.X = w2.X + px;
            w2.Y = w2.Y + py;
            w3.X = w3.X + px;
            w3.Y = w3.Y + py;
        }

    }
}
