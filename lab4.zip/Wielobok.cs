﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Wielobok : ICloneable
    {
        List<Punkt> wierzcholki;
        string nazwa;

        public Wielobok(List<Punkt> wierzcholki, string nazwa)
        {
            this.wierzcholki = wierzcholki;
            this.nazwa = nazwa;
        }

        public Wielobok(Wielobok other)
        {
            this.wierzcholki = other.wierzcholki;
            this.nazwa = other.nazwa;
        }

        public Wielobok Clone()
        {
            return new Wielobok(this);
        }
        object ICloneable.Clone()
        {
            return Clone();
        }

        public double obwod()
        {
            double a= wierzcholki[0].odleglosc(wierzcholki[0],wierzcholki[wierzcholki.Count-1]);
            for (int i = 1; i < wierzcholki.Count; i++)
            {
                a = a + wierzcholki[i].odleglosc(wierzcholki[i], wierzcholki[i - 1]);
            }
            return a;
        }

        public void dodaj(Punkt a)
        {
            wierzcholki.Add(a);
        }




        public void przesun(double px, double py)
        {
            for (int i=0; i < wierzcholki.Count; i++)
            {
                wierzcholki[i].X = wierzcholki[i].X + px;
                wierzcholki[i].Y = wierzcholki[i].Y + py;
            }
        }

    }
}
