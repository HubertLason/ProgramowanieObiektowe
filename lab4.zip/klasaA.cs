﻿using System;

namespace ConsoleApp1
{
    class klasaA
    {
        public void metoda()
        {
            Console.WriteLine("To nie jest metoda wirtualna");
        }

        public virtual void metodawirtualna() {
            Console.WriteLine("To jest metoda wirtualna wywołana w klasie A");
        }

    }
}
