﻿using System;

namespace ConsoleApp1
{
    class klasaB : klasaA
    {
        public override void metodawirtualna()
        {
            Console.WriteLine("To jest metoda wirtualna wywołana w klasie B");
        }

    }
}