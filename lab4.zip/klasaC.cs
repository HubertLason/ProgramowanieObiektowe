﻿using System;


namespace ConsoleApp1
{
    class klasaC : klasaB
    {
        public override void metodawirtualna()
        {
            Console.WriteLine("To jest metoda wirtualna wywołana w klasie C");
            base.metoda(); // dodanie tego powoduje wywołanie metody "metoda()" z klasy bazowej przy wywołaniu metody w klasie C
        }
    }
}
